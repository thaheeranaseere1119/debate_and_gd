import GroupRoom from './GroupRoom';

export default function GroupRoomPage({
  params,
}: {
  params: { roomId: string };
}) {
  return <GroupRoom roomId={params.roomId} />;
}
