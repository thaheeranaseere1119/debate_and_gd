"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Plus, LogIn, ArrowRight } from "lucide-react";

const generateRoomId = () => Math.random().toString(36).substring(2, 9);

export default function GroupDiscussionPage() {
  const router = useRouter();
  const [roomCode, setRoomCode] = useState("");

  const handleCreateRoom = () => {
    const newRoomId = generateRoomId();
    router.push(`/group/${newRoomId}`);
  };

  const handleJoinRoom = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (roomCode.trim()) {
      router.push(`/group/${roomCode.trim()}`);
    }
  };

  return (
    <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
      <Users className="w-24 h-24 text-accent mb-4" />
      <h1 className="text-4xl font-extrabold tracking-tight font-headline text-primary sm:text-5xl md:text-6xl">
        Group Discussion
      </h1>
      <p className="mt-3 max-w-md text-center text-base text-muted-foreground sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
        Collaborate, deliberate, and grow together. Create a private room or join an existing one.
      </p>

      <Card className="mt-8 w-full max-w-md mx-auto shadow-md">
        <Tabs defaultValue="create" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="create"><Plus className="mr-2 h-4 w-4" />Create Room</TabsTrigger>
            <TabsTrigger value="join"><LogIn className="mr-2 h-4 w-4" />Join Room</TabsTrigger>
          </TabsList>
          <TabsContent value="create">
            <CardHeader>
              <CardTitle className="font-headline">Create a New Discussion Room</CardTitle>
              <CardDescription>
                Start a new session and invite others to join.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={handleCreateRoom} className="w-full">
                Create Instant Room <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </TabsContent>
          <TabsContent value="join">
            <CardHeader>
              <CardTitle className="font-headline">Join an Existing Room</CardTitle>
              <CardDescription>
                Enter the room code provided by the creator.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleJoinRoom} className="space-y-4">
                <Input
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value)}
                  placeholder="Enter room code"
                  className="font-code tracking-widest text-center"
                />
                <Button type="submit" className="w-full" disabled={!roomCode.trim()}>
                  Join Room <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
