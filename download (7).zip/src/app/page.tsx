import Link from "next/link";
import Image from "next/image";
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Swords, Users } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function Home() {
  const debateImage = PlaceHolderImages.find(p => p.id === 'home-debate');
  const groupImage = PlaceHolderImages.find(p => p.id === 'home-group');

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold tracking-tight font-headline text-primary sm:text-5xl md:text-6xl">
          Welcome to Contextual Debater
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-muted-foreground sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Sharpen your arguments. Master group discussions. Stay on point, always.
        </p>
      </div>

      <div className="mt-12 max-w-lg mx-auto grid gap-8 lg:grid-cols-2 lg:max-w-none">
        <Link href="/debate">
          <Card className="h-full group flex flex-col overflow-hidden rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:shadow-primary/20 hover:border-primary">
             <div className="overflow-hidden">
               {debateImage && (
                <Image
                  src={debateImage.imageUrl}
                  alt={debateImage.description}
                  data-ai-hint={debateImage.imageHint}
                  width={600}
                  height={400}
                  className="rounded-t-lg object-cover w-full h-48 transform transition-transform duration-300 group-hover:scale-110"
                />
              )}
             </div>
            <CardHeader className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-accent/20 rounded-full">
                  <Swords className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="text-2xl font-headline">Debate Mode</CardTitle>
              </div>
              <CardDescription>
                Engage in one-on-one debates. Choose between training with AI-generated points or competing against a live AI opponent.
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/group">
          <Card className="h-full group flex flex-col overflow-hidden rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:shadow-primary/20 hover:border-primary">
            <div className="overflow-hidden">
              {groupImage && (
                <Image
                  src={groupImage.imageUrl}
                  alt={groupImage.description}
                  data-ai-hint={groupImage.imageHint}
                  width={600}
                  height={400}
                  className="rounded-t-lg object-cover w-full h-48 transform transition-transform duration-300 group-hover:scale-110"
                />
              )}
            </div>
            <CardHeader className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-accent/20 rounded-full">
                  <Users className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="text-2xl font-headline">Group Discussion Mode</CardTitle>
              </div>
              <CardDescription>
                Create or join discussion rooms. Collaborate with others, get AI assistance, and receive performance feedback.
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>
    </div>
  );
}
