import Link from "next/link";
import Image from "next/image";
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { BookOpen, Trophy } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function DebatePage() {
    const trainingImage = PlaceHolderImages.find(p => p.id === 'debate-training');
    const competitorImage = PlaceHolderImages.find(p => p.id === 'debate-competitor');

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold tracking-tight font-headline text-primary sm:text-5xl md:text-6xl">
          Debate Mode
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-muted-foreground sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Choose your challenge. Prepare with structured points or test your skills against our AI.
        </p>
      </div>

      <div className="mt-12 max-w-lg mx-auto grid gap-8 lg:grid-cols-2 lg:max-w-none">
        <Link href="/debate/training">
          <Card className="h-full group flex flex-col overflow-hidden rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:shadow-primary/20 hover:border-primary">
            <div className="overflow-hidden">
                {trainingImage && (
                <Image
                  src={trainingImage.imageUrl}
                  alt={trainingImage.description}
                  data-ai-hint={trainingImage.imageHint}
                  width={600}
                  height={400}
                  className="rounded-t-lg object-cover w-full h-48 transform transition-transform duration-300 group-hover:scale-110"
                />
              )}
            </div>
            <CardHeader className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                 <div className="p-3 bg-accent/20 rounded-full">
                  <BookOpen className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="text-2xl font-headline">Training Mode</CardTitle>
              </div>
              <CardDescription>
                Enter a topic and get AI-generated 'For' and 'Against' points to build a strong foundation for your arguments.
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/debate/competitor">
          <Card className="h-full group flex flex-col overflow-hidden rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:shadow-primary/20 hover:border-primary">
            <div className="overflow-hidden">
              {competitorImage && (
                <Image
                  src={competitorImage.imageUrl}
                  alt={competitorImage.description}
                  data-ai-hint={competitorImage.imageHint}
                  width={600}
                  height={400}
                  className="rounded-t-lg object-cover w-full h-48 transform transition-transform duration-300 group-hover:scale-110"
                />
              )}
            </div>
            <CardHeader className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-accent/20 rounded-full">
                  <Trophy className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="text-2xl font-headline">Competitor Mode</CardTitle>
              </div>
              <CardDescription>
                Face off against a live AI opponent. Get real-time feedback and scoring to sharpen your competitive edge.
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>
    </div>
  );
}
