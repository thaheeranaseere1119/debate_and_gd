"use client";

import dynamic from "next/dynamic";
import { Loader2 } from "lucide-react";

const TrainingModeClient = dynamic(
  () => import("@/components/debate/TrainingModeClient"),
  { 
    ssr: false,
    loading: () => (
      <div className="flex h-[calc(100vh-10rem)] w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    ),
  }
);

export default function TrainingModePage() {
  return <TrainingModeClient />;
}