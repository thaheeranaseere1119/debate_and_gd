'use server';
import { config } from 'dotenv';
config();

import '@/ai/flows/act-as-debate-opponent.ts';
import '@/ai/flows/generate-debate-points.ts';
import '@/ai/flows/monitor-topic-deviation.ts';
import '@/ai/flows/suggest-group-discussion-replies.ts';
import '@/ai/flows/text-to-speech.ts';
import '@/ai/flows/summarize-debate.ts';
import '@/ai/flows/act-as-group-participant.ts';
import '@/ai/flows/summarize-group-discussion.ts';
