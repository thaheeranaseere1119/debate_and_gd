'use server';

/**
 * @fileOverview A flow to monitor group discussions for topic deviations and provide warnings.
 *
 * - monitorTopicDeviation - A function that monitors the discussion and provides warnings for topic deviations.
 * - MonitorTopicDeviationInput - The input type for the monitorTopicDeviation function.
 * - MonitorTopicDeviationOutput - The return type for the monitorTopicDeviation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MonitorTopicDeviationInputSchema = z.object({
  topic: z.string().describe('The main topic of the discussion.'),
  message: z.string().describe('The latest message in the discussion.'),
  conversationHistory: z.string().describe('The complete conversation history.'),
});
export type MonitorTopicDeviationInput = z.infer<typeof MonitorTopicDeviationInputSchema>;

const MonitorTopicDeviationOutputSchema = z.object({
  isDeviating: z.boolean().describe('Whether the message deviates from the topic.'),
  deviationReason: z.string().optional().describe('The reason for the topic deviation, if any.'),
});
export type MonitorTopicDeviationOutput = z.infer<typeof MonitorTopicDeviationOutputSchema>;

export async function monitorTopicDeviation(input: MonitorTopicDeviationInput): Promise<MonitorTopicDeviationOutput> {
  return monitorTopicDeviationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'monitorTopicDeviationPrompt',
  input: {schema: MonitorTopicDeviationInputSchema},
  output: {schema: MonitorTopicDeviationOutputSchema},
  prompt: `You are an AI assistant monitoring a group discussion to ensure it stays on topic.\n\nTopic: {{{topic}}}\n\nLatest Message: {{{message}}}\n\nConversation History: {{{conversationHistory}}}\n\nDetermine if the latest message deviates from the main topic of the discussion. If it does, explain the reason for the deviation. If not, isDeviating should be false and deviationReason should be null.\n\nOutput in JSON format: {"isDeviating": boolean, "deviationReason": string | null}`,
});

const monitorTopicDeviationFlow = ai.defineFlow(
  {
    name: 'monitorTopicDeviationFlow',
    inputSchema: MonitorTopicDeviationInputSchema,
    outputSchema: MonitorTopicDeviationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
