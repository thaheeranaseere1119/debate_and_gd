'use server';
/**
 * @fileOverview This file defines a Genkit flow for suggesting replies in a group discussion.
 *
 * The flow takes the current discussion context and user query as input, and provides
 * suggestions for replies, contradictions, or clarity improvements.
 *
 * @fileOverview A Genkit flow for suggesting replies in group discussions.
 *
 * - `suggestReply`: A function that suggests replies based on the discussion context.
 * - `SuggestReplyInput`: The input type for the `suggestReply` function.
 * - `SuggestReplyOutput`: The output type for the `suggestReply` function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestReplyInputSchema = z.object({
  discussionContext: z
    .string()
    .describe('The current context of the group discussion.'),
  userQuery: z
    .string()
    .describe(
      'The user query, which can be a request for a reply suggestion, contradiction, or clarity improvement.'
    ),
});
export type SuggestReplyInput = z.infer<typeof SuggestReplyInputSchema>;

const SuggestReplyOutputSchema = z.object({
  suggestion: z.string().describe('The AI-generated suggestion.'),
});
export type SuggestReplyOutput = z.infer<typeof SuggestReplyOutputSchema>;

export async function suggestReply(
  input: SuggestReplyInput
): Promise<SuggestReplyOutput> {
  return suggestReplyFlow(input);
}

const suggestReplyPrompt = ai.definePrompt({
  name: 'suggestReplyPrompt',
  input: {schema: SuggestReplyInputSchema},
  output: {schema: SuggestReplyOutputSchema},
  prompt: `You are an AI assistant helping a user in a group discussion.
The discussion so far:
{{{discussionContext}}}

The user wants help with the following: "{{{userQuery}}}"

Based on this, provide a concise and relevant suggestion for the user to say next.
Format your response as a JSON object with a single key "suggestion".`,
});

const suggestReplyFlow = ai.defineFlow(
  {
    name: 'suggestReplyFlow',
    inputSchema: SuggestReplyInputSchema,
    outputSchema: SuggestReplyOutputSchema,
  },
  async input => {
    const {output} = await suggestReplyPrompt(input);
    return output!;
  }
);
