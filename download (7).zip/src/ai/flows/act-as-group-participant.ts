'use server';
/**
 * @fileOverview This file defines a Genkit flow for an AI to act as a participant in a group discussion.
 *
 * - actAsGroupParticipant - A function that allows the AI to generate a response as a virtual person in the chat.
 * - ActAsGroupParticipantInput - The input type for the function.
 * - ActAsGroupParticipantOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ActAsGroupParticipantInputSchema = z.object({
  topic: z.string().describe('The topic of the discussion.'),
  conversationHistory: z.string().describe('The history of the conversation.'),
});
export type ActAsGroupParticipantInput = z.infer<typeof ActAsGroupParticipantInputSchema>;

const ActAsGroupParticipantOutputSchema = z.object({
  aiResponse: z.string().describe("The AI's response as a participant."),
});
export type ActAsGroupParticipantOutput = z.infer<typeof ActAsGroupParticipantOutputSchema>;

export async function actAsGroupParticipant(input: ActAsGroupParticipantInput): Promise<ActAsGroupParticipantOutput> {
  return actAsGroupParticipantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'actAsGroupParticipantPrompt',
  input: {schema: ActAsGroupParticipantInputSchema},
  output: {schema: ActAsGroupParticipantOutputSchema},
  prompt: `You are a participant in a group discussion. Your name is 'AI Assistant'.
  Your personality is helpful, insightful, and slightly inquisitive.
  You should contribute to the conversation, ask clarifying questions, and build upon others' ideas.
  Do not dominate the conversation. Keep your responses concise and relevant to the topic.

  Topic: {{{topic}}}
  Conversation History:
  {{{conversationHistory}}}

  Based on the history, provide your response as the 'AI Assistant'.
  Format your response as a JSON object with a single key "aiResponse".`,
});

const actAsGroupParticipantFlow = ai.defineFlow(
  {
    name: 'actAsGroupParticipantFlow',
    inputSchema: ActAsGroupParticipantInputSchema,
    outputSchema: ActAsGroupParticipantOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
