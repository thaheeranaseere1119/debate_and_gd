
'use server';

/**
 * @fileOverview Generates FOR and AGAINST points for a given debate topic.
 *
 * - generateDebatePoints - A function that generates debate points.
 * - GenerateDebatePointsInput - The input type for the generateDebatePoints function.
 * - GenerateDebatePointsOutput - The return type for the generateDebatePoints function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateDebatePointsInputSchema = z.object({
  topic: z.string().describe('The topic for which to generate debate points.'),
});
export type GenerateDebatePointsInput = z.infer<typeof GenerateDebatePointsInputSchema>;

const GenerateDebatePointsOutputSchema = z.object({
  forPoints: z.array(z.string()).describe('A list of at least 10 points in favor of the topic.'),
  againstPoints: z.array(z.string()).describe('A list of at least 10 points against the topic.'),
});
export type GenerateDebatePointsOutput = z.infer<typeof GenerateDebatePointsOutputSchema>;

export async function generateDebatePoints(input: GenerateDebatePointsInput): Promise<GenerateDebatePointsOutput> {
  return generateDebatePointsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateDebatePointsPrompt',
  input: {schema: GenerateDebatePointsInputSchema},
  output: {schema: GenerateDebatePointsOutputSchema},
  prompt: `You are an AI assistant that generates debate points for a given topic.

  Topic: {{{topic}}}

  Generate a list of at least 10 points in favor of the topic and a list of at least 10 points against the topic.

  Format the output as a JSON object with the following keys:
  - forPoints: A list of at least 10 points in favor of the topic.
  - againstPoints: A list of at least 10 points against the topic.

  The points should be clear, concise, and persuasive.
  `,
});

const generateDebatePointsFlow = ai.defineFlow(
  {
    name: 'generateDebatePointsFlow',
    inputSchema: GenerateDebatePointsInputSchema,
    outputSchema: GenerateDebatePointsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
