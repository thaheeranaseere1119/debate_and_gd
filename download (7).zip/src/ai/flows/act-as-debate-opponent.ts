'use server';
/**
 * @fileOverview This file defines a Genkit flow for the ActAsDebateOpponent story, where the AI acts as a live debate opponent.
 *
 * - actAsDebateOpponent - A function that initiates and manages the debate with the AI opponent.
 * - ActAsDebateOpponentInput - The input type for the actAsDebateOpponent function.
 * - ActAsDebateOpponentOutput - The return type for the actAsDebateOpponent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ActAsDebateOpponentInputSchema = z.object({
  topic: z.string().describe('The topic of the debate.'),
  userStatement: z.string().describe("The user's statement or argument."),
  conversationHistory: z
    .string()
    .describe('The history of the conversation thus far'),
});
export type ActAsDebateOpponentInput = z.infer<
  typeof ActAsDebateOpponentInputSchema
>;

const ActAsDebateOpponentOutputSchema = z.object({
  aiResponse: z.string().describe("The AI opponent's response."),
  argumentStrength: z
    .number()
    .describe(
      'The AI evaluation of the users argument strength on a scale of 1-10'
    ),
  logicalConsistency: z
    .number()
    .describe(
      'The AI evaluation of the users logical consistency on a scale of 1-10'
    ),
  relevance: z
    .number()
    .describe(
      'The AI evaluation of the users argument relevance to the topic on a scale of 1-10'
    ),
  clarity: z
    .number()
    .describe('The AI evaluation of the users argument clarity on a scale of 1-10'),
  strongPointExplanation: z
    .string()
    .describe('Explanation of the users strong points'),
  weakPointExplanation: z
    .string()
    .describe('Explanation of the users weak points'),
  improvementSuggestions: z
    .string()
    .describe('Suggestions for improvement on the users argument'),
  isDeviating: z
    .boolean()
    .describe('Whether the message deviates from the topic.'),
  deviationReason: z
    .string()
    .optional()
    .describe('The reason for the topic deviation, if any.'),
});
export type ActAsDebateOpponentOutput = z.infer<
  typeof ActAsDebateOpponentOutputSchema
>;

export async function actAsDebateOpponent(
  input: ActAsDebateOpponentInput
): Promise<ActAsDebateOpponentOutput> {
  return actAsDebateOpponentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'actAsDebateOpponentPrompt',
  input: {schema: ActAsDebateOpponentInputSchema},
  output: {schema: ActAsDebateOpponentOutputSchema},
  prompt: `You are a live debate opponent and a discussion moderator. Your goal is to challenge the user's arguments, referencing their previous inputs and maintaining a consistent stance on the topic. At the same time, you must monitor the conversation for topic deviation.

  Topic: {{{topic}}}
  Conversation History: {{{conversationHistory}}}
  User's Current Statement: {{{userStatement}}}

  First, as your most important task, determine if the user's current statement deviates from the main topic. If it does, set 'isDeviating' to true and provide a clear 'deviationReason'. Otherwise, set 'isDeviating' to false and the reason to null.

  Next, respond to the user with a strong, contradictory argument that challenges their statement.

  Finally, evaluate the user's argument based on the following rubric and provide a score from 1-10 for each category.

  **Scoring Rubric:**
  - **Argument Strength (1-10):**
    - 1-3: Very weak. Unsupported claims, no evidence.
    - 4-6: Developing. Some claims are supported but evidence is weak or irrelevant.
    - 7-8: Strong. Most claims are well-supported with relevant evidence.
    - 9-10: Very strong. Compelling arguments backed by strong, diverse evidence and clear reasoning.
  - **Logical Consistency (1-10):**
    - 1-3: Illogical. Contains major fallacies and contradictions.
    - 4-6: Inconsistent. Some logical leaps or minor fallacies.
    - 7-8: Mostly logical. Arguments follow a clear sequence, few to no fallacies.
    - 9-10: Highly logical. Arguments are tightly reasoned, free of fallacies, and internally consistent.
  - **Relevance (1-10):**
    - 1-3: Irrelevant. The argument does not address the topic.
    - 4-6: Partially relevant. Touches on the topic but includes unrelated points.
    - 7-8: Relevant. The argument is clearly connected to the topic.
    - 9-10: Highly relevant. Directly and effectively addresses the core issues of the topic.
  - **Clarity (1-10):**
    - 1-3: Unclear. Vague language, confusing sentence structure.
    - 4-6: Somewhat clear. The main point is understandable but requires effort.
    - 7-8: Clear. The argument is easy to understand and well-organized.
    - 9-10: Exceptionally clear. Articulate, precise, and easy to follow.

  After scoring, provide a brief 'strongPointExplanation' and 'weakPointExplanation', and offer 'improvementSuggestions'.

  Format your entire response as a single JSON object.`,
});

const actAsDebateOpponentFlow = ai.defineFlow(
  {
    name: 'actAsDebateOpponentFlow',
    inputSchema: ActAsDebateOpponentInputSchema,
    outputSchema: ActAsDebateOpponentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
