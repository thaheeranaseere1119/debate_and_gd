'use server';
/**
 * @fileOverview This file defines a Genkit flow for summarizing a debate.
 *
 * - summarizeDebate - A function that takes the debate history and provides a summary.
 * - SummarizeDebateInput - The input type for the summarizeDebate function.
 * - SummarizeDebateOutput - The return type for the summarizeDebate function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const SummarizeDebateInputSchema = z.object({
  topic: z.string().describe('The topic of the debate.'),
  conversationHistory: z
    .string()
    .describe('The entire history of the conversation.'),
});
export type SummarizeDebateInput = z.infer<typeof SummarizeDebateInputSchema>;

const SummarizeDebateOutputSchema = z.object({
  overallScore: z
    .number()
    .describe(
      'An overall performance score for the user in the debate, from 1 to 10.'
    ),
  strongestArgument: z
    .string()
    .describe("The user's strongest argument during the debate, with an explanation of why it was effective."),
  weakestArgument: z
    .string()
    .describe("The user's weakest argument during the debate, with an explanation of why it was ineffective."),
  conclusion: z
    .string()
    .describe(
      'A concluding summary of the debate, highlighting key moments, overall performance, and final advice.'
    ),
});
export type SummarizeDebateOutput = z.infer<typeof SummarizeDebateOutputSchema>;

export async function summarizeDebate(
  input: SummarizeDebateInput
): Promise<SummarizeDebateOutput> {
  return summarizeDebateFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeDebatePrompt',
  input: { schema: SummarizeDebateInputSchema },
  output: { schema: SummarizeDebateOutputSchema },
  prompt: `You are an AI debate coach. You will analyze the provided debate transcript and provide a final summary of the user's performance.

  Debate Topic: {{{topic}}}
  Conversation History:
  {{{conversationHistory}}}

  Based on the entire debate, evaluate the user's performance and provide the following:

  1.  **Overall Performance Score (1-10):** Calculate this score based on a holistic view of their arguments, consistency, and persuasiveness throughout the debate, using the rubric below.
      - **1-3 (Novice):** Struggled to form coherent arguments, often went off-topic, and did not effectively counter opponent's points.
      - **4-6 (Developing):** Made some valid points but lacked consistent evidence, structure, or relevance. Showed potential but needs practice.
      - **7-8 (Proficient):** Consistently presented strong, logical, and relevant arguments. Effectively engaged with the opponent's points.
      - **9-10 (Masterful):** Dominated the debate with exceptionally clear, well-supported, and persuasive arguments. Expertly dismantled opposing views.

  2.  **Strongest Argument:** Identify the single best argument or point the user made. Quote it or describe it, and explain *why* it was so effective (e.g., "it used powerful evidence," "it masterfully exposed a logical flaw").

  3.  **Weakest Argument:** Identify the single weakest argument or point the user made. Quote it or describe it, and explain *why* it was ineffective (e.g., "it was an unsupported assertion," "it was easily refuted," "it was irrelevant to the topic").

  4.  **Conclusion:** Provide a brief concluding summary of the user's overall performance, highlighting key moments and offering concrete, actionable advice for future debates.

  Format your response as a single JSON object.`,
});

const summarizeDebateFlow = ai.defineFlow(
  {
    name: 'summarizeDebateFlow',
    inputSchema: SummarizeDebateInputSchema,
    outputSchema: SummarizeDebateOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
