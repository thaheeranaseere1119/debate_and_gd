'use server';
/**
 * @fileOverview This file defines a Genkit flow for summarizing a group discussion and scoring a user's performance.
 *
 * - summarizeGroupDiscussion - A function that provides a summary and scores.
 * - SummarizeGroupDiscussionInput - The input type for the function.
 * - SummarizeGroupDiscussionOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeGroupDiscussionInputSchema = z.object({
  topic: z.string().describe('The topic of the discussion.'),
  conversationHistory: z.string().describe('The entire history of the conversation, with messages prefixed by sender (e.g., "You: ...", "Alice: ...").'),
});
export type SummarizeGroupDiscussionInput = z.infer<typeof SummarizeGroupDiscussionInputSchema>;

const SummarizeGroupDiscussionOutputSchema = z.object({
  collaborationScore: z.number().describe("A score from 1-10 on the user's ability to collaborate, build on others' ideas, and foster a positive environment."),
  relevanceScore: z.number().describe("A score from 1-10 on how well the user stayed on topic."),
  impactScore: z.number().describe("A score from 1-10 on the user's overall impact on the discussion."),
  overallScore: z.number().describe("An average of the other scores, from 1-10."),
  strengths: z.string().describe("An analysis of the user's main strengths in the discussion."),
  weaknesses: z.string().describe("An analysis of the user's main weaknesses or areas for improvement."),
  summary: z.string().describe("A concluding summary of the user's performance and key takeaways."),
});
export type SummarizeGroupDiscussionOutput = z.infer<typeof SummarizeGroupDiscussionOutputSchema>;

export async function summarizeGroupDiscussion(input: SummarizeGroupDiscussionInput): Promise<SummarizeGroupDiscussionOutput> {
  return summarizeGroupDiscussionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeGroupDiscussionPrompt',
  input: {schema: SummarizeGroupDiscussionInputSchema},
  output: {schema: SummarizeGroupDiscussionOutputSchema},
  prompt: `You are an AI discussion coach. Analyze the provided group discussion transcript, focusing on the performance of the user identified as "You".

  Discussion Topic: {{{topic}}}
  Conversation History:
  {{{conversationHistory}}}

  Evaluate the "You" user's performance based on the following rubric and provide scores from 1 to 10 for each category:

  **Scoring Rubric:**
  - **Collaboration Score (1-10):**
    - 1-3: Did not engage with others, ignored questions, or was dismissive.
    - 4-6: Acknowledged others but did not actively build on their ideas.
    - 7-8: Actively listened, asked clarifying questions, and built upon others' points.
    - 9-10: Masterfully facilitated discussion, synthesized multiple viewpoints, and elevated the group's understanding.
  - **Relevance Score (1-10):**
    - 1-3: Frequently off-topic, introduced irrelevant tangents.
    - 4-6: Mostly on-topic but occasionally drifted.
    - 7-8: Consistently stayed on topic and made relevant contributions.
    - 9-10: Kept the discussion focused and brought it back on track when others deviated.
  - **Impact Score (1-10):**
    - 1-3: Contributions had little to no effect on the conversation's direction.
    - 4-6: Made some interesting points but did not significantly shape the discussion.
    - 7-8: Contributions were influential and helped move the conversation forward.
    - 9-10: Provided key insights that fundamentally shifted or advanced the discussion.

  Calculate an **overallScore** by averaging the three scores above.

  Then, provide a qualitative analysis:
  - **strengths**: What was the user's single greatest strength? (e.g., asking insightful questions, providing data-driven evidence, synthesizing ideas).
  - **weaknesses**: What is the single biggest area for improvement? (e.g., interrupting others, not staying on topic, making unsupported claims).
  - **summary**: A brief concluding summary of the user's performance with one key takeaway or piece of advice.

  Format your response as a single JSON object.`,
});

const summarizeGroupDiscussionFlow = ai.defineFlow(
  {
    name: 'summarizeGroupDiscussionFlow',
    inputSchema: SummarizeGroupDiscussionInputSchema,
    outputSchema: SummarizeGroupDiscussionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
