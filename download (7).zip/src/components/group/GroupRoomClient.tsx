'use client';

import { useState, useRef, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import {
  Bot,
  Send,
  Sparkles,
  Users,
  MessageSquareQuote,
  MessageSquareWarning,
  MessageSquarePlus,
  ShieldAlert,
  Loader2,
  Lightbulb,
  Goal,
  BookCheck,
  Zap,
  Mic,
  MicOff,
  Play,
  Pause,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { suggestReply, type SuggestReplyOutput } from '@/ai/flows/suggest-group-discussion-replies';
import { actAsGroupParticipant } from '@/ai/flows/act-as-group-participant';
import { monitorTopicDeviation } from '@/ai/flows/monitor-topic-deviation';
import { summarizeGroupDiscussion, type SummarizeGroupDiscussionOutput } from '@/ai/flows/summarize-group-discussion';
import { textToSpeech } from '@/ai/flows/text-to-speech';

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
}
declare const window: {
  SpeechRecognition: new () => SpeechRecognition;
  webkitSpeechRecognition: new () => SpeechRecognition;
};


const mockParticipants = [
  { name: 'Alice', avatar: 'https://i.pravatar.cc/150?u=alice' },
  { name: 'Bob', avatar: 'https://i.pravatar.cc/150?u=bob' },
  { name: 'You', avatar: 'https://i.pravatar.cc/150?u=you' },
  { name: 'Charlie', avatar: 'https://i.pravatar.cc/150?u=charlie' },
  { name: 'AI Assistant', avatar: '' },
];

type Message = {
  id: string;
  sender: string;
  content: string;
  avatar: string;
  isAI?: boolean;
  isWarning?: boolean;
  audioDataUri?: string | null;
};

const initialMessages: Message[] = [
  {
    id: '1',
    sender: 'Alice',
    content: 'So, to kick things off, what does everyone think about the future of remote work? Is it here to stay?',
    avatar: 'https://i.pravatar.cc/150?u=alice',
  },
  {
    id: '2',
    sender: 'Bob',
    content: 'I think it is. The flexibility is a huge plus for work-life balance. Companies that force a full return to the office might lose talent.',
    avatar: 'https://i.pravatar.cc/150?u=bob',
  },
];

const DISCUSSION_TOPIC = 'The future of remote work';

export default function GroupRoomClient({ roomId }: { roomId: string }) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputMessage, setInputMessage] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summary, setSummary] = useState<SummarizeGroupDiscussionOutput | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [activeAudio, setActiveAudio] = useState<string | null>(null);

  const { toast, dismiss } = useToast();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const activeToastId = useRef<string | null>(null);

  useEffect(() => {
    if (scrollAreaRef.current) {
      setTimeout(() => {
        scrollAreaRef.current?.scrollTo({
          top: scrollAreaRef.current.scrollHeight,
          behavior: "smooth",
        });
      }, 100);
    }
  }, [messages]);
  
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        setInputMessage(finalTranscript + interimTranscript);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        toast({ title: 'Speech Recognition Error', description: event.error, variant: 'destructive' });
        setIsRecording(false);
      };

      recognitionRef.current.onend = () => {
        if (isRecording) {
            setIsRecording(false);
        }
      };
    }
  }, [toast]);

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      if (!recognitionRef.current) {
        toast({ title: 'Unsupported', description: 'Speech recognition is not supported in your browser.', variant: 'destructive' });
        return;
      }
      recognitionRef.current?.start();
      setIsRecording(true);
    }
  };

  const playAudio = (audioDataUri: string, id: string) => {
    if (audioRef.current) {
      if (activeAudio === id) {
        audioRef.current.pause();
        setActiveAudio(null);
      } else {
        audioRef.current.src = audioDataUri;
        audioRef.current.play().catch((e) => console.error("Audio playback failed:", e));
        setActiveAudio(id);
      }
    }
  };

   useEffect(() => {
    const audioElement = audioRef.current;
    const handleEnded = () => setActiveAudio(null);
    if (audioElement) {
        audioElement.addEventListener('ended', handleEnded);
        return () => {
            audioElement.removeEventListener('ended', handleEnded);
        };
    }
  }, []);

  const generateAndSetAudio = async (text: string, messageId: string) => {
    try {
      const audioResult = await textToSpeech(text);
      setMessages(prev => 
        prev.map(m => m.id === messageId ? { ...m, audioDataUri: audioResult.media } : m)
      );
    } catch(e) {
      console.error("Failed to generate audio for message " + messageId, e);
      setMessages(prev => 
        prev.map(m => m.id === messageId ? { ...m, audioDataUri: 'error' } : m)
      );
    }
  };

  const getConversationHistory = (currentMessages: Message[]) => {
    return currentMessages.map(m => `${m.sender}: ${m.content}`).join('\n');
  }

  const handleSend = async () => {
    if (!inputMessage.trim()) return;

    if(isRecording) {
        recognitionRef.current?.stop();
        setIsRecording(false);
    }
    
    const newMessage: Message = {
        id: Date.now().toString(),
        sender: "You",
        content: inputMessage,
        avatar: 'https://i.pravatar.cc/150?u=you'
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    setInputMessage('');
    setIsAiLoading(true);

    try {
      const history = getConversationHistory(updatedMessages);

      // Check for topic deviation
      const deviationResult = await monitorTopicDeviation({
        topic: DISCUSSION_TOPIC,
        message: newMessage.content,
        conversationHistory: history,
      });

      if (deviationResult.isDeviating) {
        const warningId = `${newMessage.id}-warning`;
        const warningMessage: Message = {
          id: warningId,
          sender: 'Moderator',
          content: `Warning: This message seems to be deviating from the topic. Reason: ${deviationResult.deviationReason}`,
          avatar: '',
          isAI: true,
          isWarning: true,
          audioDataUri: null
        };
        setMessages(prev => [...prev, warningMessage]);
        generateAndSetAudio(warningMessage.content, warningId);
      }

      // Get AI participant response
      const aiResult = await actAsGroupParticipant({
        topic: DISCUSSION_TOPIC,
        conversationHistory: history,
      });

      const aiMessageId = `${newMessage.id}-ai`;
      const aiMessage: Message = {
        id: aiMessageId,
        sender: 'AI Assistant',
        content: aiResult.aiResponse,
        avatar: '',
        isAI: true,
        audioDataUri: null,
      };
      setMessages(prev => [...prev, aiMessage]);
      generateAndSetAudio(aiMessage.content, aiMessageId);

    } catch (error) {
      console.error("AI participant error:", error);
      toast({
        variant: "destructive",
        title: "AI Error",
        description: "The AI participant is having trouble responding.",
      });
    } finally {
      setIsAiLoading(false);
    }
  };
  
  const handleAiAction = async (action: string, userQuery: string) => {
    setIsAiLoading(true);
    if(activeToastId.current) {
        dismiss(activeToastId.current);
    }
    try {
      const discussionContext = getConversationHistory(messages);
      
      const result = await suggestReply({
        discussionContext,
        userQuery,
      });

      const suggestionText = result.suggestion;

      const audioResult = await textToSpeech(suggestionText);
      
      const { id } = toast({
        duration: 10000,
        title: "AI Suggestion",
        description: (
          <div>
            <p>{suggestionText}</p>
            <div className="flex items-center gap-2 mt-2">
               <Button variant="secondary" size="sm" onClick={() => setInputMessage(suggestionText)}>
                Use Suggestion
              </Button>
               <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => playAudio(audioResult.media, 'toast-audio')}>
                  {activeAudio === 'toast-audio' ? <Pause className="w-4 h-4"/> : <Play className="w-4 h-4"/>}
               </Button>
            </div>
          </div>
        ),
      });
      activeToastId.current = id;

    } catch (error) {
      console.error("AI suggestion error:", error);
      toast({
        variant: "destructive",
        title: "AI Error",
        description: "Could not get a suggestion at this time.",
      });
    } finally {
      setIsAiLoading(false);
    }
  }

  const handleSummarize = async () => {
    setIsSummarizing(true);
    try {
      const conversationHistory = getConversationHistory(messages);
      const summaryResult = await summarizeGroupDiscussion({
        topic: DISCUSSION_TOPIC,
        conversationHistory,
      });
      setSummary(summaryResult);
    } catch (error) {
      console.error("Error summarizing discussion:", error);
      toast({
        title: "Error Summarizing",
        description: "Could not generate the discussion summary.",
        variant: "destructive",
      });
    } finally {
      setIsSummarizing(false);
    }
  };

  const ScoreBar = ({ label, value }: { label: string; value: number }) => (
    <div className="space-y-1">
      <div className="flex justify-between items-baseline">
        <Label className="text-sm font-medium">{label}</Label>
        <span className="text-sm font-bold text-primary">{value}/10</span>
      </div>
      <Progress
        value={value * 10}
        className="h-2"
        aria-label={`${label}: ${value} out of 10`}
      />
    </div>
  );

  if (summary) {
    return (
      <div className="container mx-auto py-12">
        <Card className="max-w-3xl mx-auto">
          <CardHeader className="text-center">
            <BookCheck className="mx-auto h-16 w-16 text-primary" />
            <CardTitle className="text-3xl font-headline mt-4">
              Discussion Summary
            </CardTitle>
            <CardDescription>Topic: {DISCUSSION_TOPIC}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-muted-foreground">Overall Performance Score</p>
              <p className="text-6xl font-bold text-primary">
                {summary.overallScore.toFixed(1)}
                <span className="text-3xl text-muted-foreground">/10</span>
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <ScoreBar label="Collaboration" value={summary.collaborationScore} />
                <ScoreBar label="Relevance" value={summary.relevanceScore} />
                <ScoreBar label="Impact" value={summary.impactScore} />
            </div>
            <div className="space-y-4 text-sm">
              <div>
                <h4 className="font-semibold flex items-center gap-2 text-green-600 dark:text-green-500">
                  <Zap /> Strengths
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.strengths}
                </p>
              </div>
              <div>
                <h4 className="font-semibold flex items-center gap-2 text-red-600 dark:text-red-500">
                  <ShieldAlert /> Areas for Improvement
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.weaknesses}
                </p>
              </div>
               <div>
                <h4 className="font-semibold flex items-center gap-2 text-blue-600 dark:text-blue-500">
                  <Sparkles /> Final Summary
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.summary}
                </p>
              </div>
            </div>
             <Button onClick={() => window.location.reload()} className="w-full">
                Start a New Discussion
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 h-[calc(100vh-5rem)]">
      <audio ref={audioRef} className="hidden" />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        <div className="lg:col-span-2 flex flex-col h-full bg-card border rounded-lg shadow-sm">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle className="font-headline text-lg">
                Group Discussion
              </CardTitle>
              <CardDescription>
                Room ID: <span className="font-mono">{roomId}</span> | Topic: {DISCUSSION_TOPIC}
              </CardDescription>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" disabled={isAiLoading || isSummarizing}>
                  <Goal className="mr-2 h-4 w-4" /> End Discussion
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>End and score discussion?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will end the current discussion and generate a summary of your performance. You won't be able to send more messages.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSummarize}>
                    {isSummarizing ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    Get Score
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardHeader>
          <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
            <div className="space-y-6">
              {messages.map((msg, index) => (
                <div
                  key={msg.id}
                  className={cn(
                    'flex items-start gap-3 w-full',
                     msg.sender === "You" ? 'justify-end' : 'justify-start'
                  )}
                >
                  {msg.sender !== "You" && (
                    <Avatar>
                       {msg.isAI ? (
                          <AvatarFallback className={cn(msg.isWarning ? "bg-destructive/80" : "bg-accent")}>
                           {msg.isWarning ? <ShieldAlert className="text-destructive-foreground"/> : <Bot />}
                          </AvatarFallback>
                        ) : (
                          <>
                           <AvatarImage src={msg.avatar} alt={msg.sender} />
                           <AvatarFallback>{msg.sender.charAt(0)}</AvatarFallback>
                          </>
                        )}
                    </Avatar>
                  )}
                  <div
                    className={cn(
                      'max-w-xl rounded-lg p-3 text-sm shadow',
                       msg.isWarning ? "bg-destructive/10 border border-destructive/20 text-destructive-foreground" 
                       : msg.sender === 'You' ? 'bg-primary text-primary-foreground' 
                       : msg.isAI ? 'bg-accent/20'
                       : 'bg-muted'
                    )}
                  >
                     <p className="font-bold text-xs mb-1">{msg.sender}</p>
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                    {msg.isAI && (
                        <div className="mt-2">
                            {msg.audioDataUri === null ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                            ) : msg.audioDataUri === 'error' ? null
                              : msg.audioDataUri ? (
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => playAudio(msg.audioDataUri!, msg.id)}>
                                    {activeAudio === msg.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                                </Button>
                            ) : null}
                        </div>
                    )}
                  </div>
                  {msg.sender === "You" && (
                     <Avatar>
                        <AvatarImage src={msg.avatar} alt={msg.sender} />
                        <AvatarFallback>{msg.sender.charAt(0)}</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
               {isAiLoading && !messages.some(m => m.isAI && m.content === '') && (
                <div className="flex items-start gap-3 justify-start">
                  <Avatar>
                    <AvatarFallback className="bg-accent">
                      <Bot />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-muted rounded-lg p-3 shadow">
                    <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          <div className="p-4 border-t bg-background/80 rounded-b-lg">
            <div className="relative">
              <Textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={isRecording ? "Listening..." : "Type your message..."}
                className="pr-36"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                rows={1}
                disabled={isAiLoading || isSummarizing}
              />
              <div className="absolute top-1/2 -translate-y-1/2 right-3 flex items-center gap-1">
                 <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleAiAction('Suggest a reply', 'Suggest a reply to the ongoing conversation.')}
                    disabled={isAiLoading || isSummarizing}
                    aria-label="Ask AI for a suggestion"
                  >
                    <Sparkles className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleRecording}
                    disabled={isAiLoading || isSummarizing}
                    aria-label="Use Voice Input"
                    className={cn(isRecording && "text-destructive")}
                >
                  {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
                  <Button
                    size="icon"
                    onClick={handleSend}
                    disabled={!inputMessage.trim() || isAiLoading || isSummarizing}
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 h-full overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2 text-base">
                <Users className="text-accent" /> Participants (
                {mockParticipants.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-48">
                <div className="space-y-4">
                  {mockParticipants.map((p) => (
                    <div key={p.name} className="flex items-center gap-3">
                      <Avatar>
                        {p.name === 'AI Assistant' ? (
                          <AvatarFallback className="bg-accent"><Bot /></AvatarFallback>
                        ) : (
                          <>
                           <AvatarImage src={p.avatar} alt={p.name} />
                           <AvatarFallback>{p.name.charAt(0)}</AvatarFallback>
                          </>
                        )}
                      </Avatar>
                      <p className="font-medium text-sm">{p.name}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
          <Card className="flex-grow">
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2 text-base">
                <Sparkles className="text-accent" /> AI Assistance
              </CardTitle>
              <CardDescription>
                Use AI to enhance your participation.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
             <Button variant="outline" onClick={() => handleAiAction('Suggest a reply', 'Suggest a reply to the ongoing conversation.')} disabled={isAiLoading || isSummarizing}>
                {isAiLoading ? <Loader2 className="mr-2 animate-spin" /> : <MessageSquarePlus className="mr-2" />} 
                Ask AI for a reply
              </Button>
              <Button variant="outline" onClick={() => handleAiAction('Suggest a contradiction', 'Suggest a contradiction to the last point.')} disabled={isAiLoading || isSummarizing}>
                <MessageSquareWarning className="mr-2" /> Ask AI for a contradiction
              </Button>
              <Button variant="outline" onClick={() => handleAiAction('Improve clarity of my last point', 'Help me improve the clarity of my last point.')} disabled={isAiLoading || isSummarizing}>
                <MessageSquareQuote className="mr-2" /> Ask AI to improve my last point
              </Button>
              <Button variant="outline" onClick={() => handleAiAction('Suggest what to do next', 'Suggest a way to improve the overall conversation, like asking a clarifying question or introducing a new angle.')} disabled={isAiLoading || isSummarizing}>
                {isAiLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Lightbulb className="mr-2 h-4 w-4" />}
                Ask AI what to do next
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
