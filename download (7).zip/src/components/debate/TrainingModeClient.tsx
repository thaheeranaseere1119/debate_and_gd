
"use client";

import { useState, useRef, useEffect } from "react";
import {
  generateDebatePoints,
  type GenerateDebatePointsOutput,
} from "@/ai/flows/generate-debate-points";
import { textToSpeech, type TextToSpeechOutput } from "@/ai/flows/text-to-speech";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ThumbsUp, ThumbsDown, Loader2, BookOpen, Bot, Play, Pause, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type DebatePoint = {
  text: string;
  audio: TextToSpeechOutput | null;
  isLoadingAudio: boolean;
  elaboration?: string;
  isElaborating?: boolean;
};

type DebatePointsState = {
  forPoints: DebatePoint[];
  againstPoints: DebatePoint[];
};

export default function TrainingModeClient() {
  const [topic, setTopic] = useState("");
  const [debatePoints, setDebatePoints] = useState<DebatePointsState | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [activeAudio, setActiveAudio] = useState<string | null>(null);
  const isAudioLoadingRef = useRef(false);

  useEffect(() => {
    const audioElement = audioRef.current;
    const onEnded = () => setActiveAudio(null);
    if (audioElement) {
      audioElement.addEventListener('ended', onEnded);
      return () => {
        audioElement.removeEventListener('ended', onEnded);
      };
    }
  }, []);


  const handleTopicSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsLoading(true);
    setDebatePoints(null);
    try {
      const result = await generateDebatePoints({ topic });
      const initialDebatePoints: DebatePointsState = {
        forPoints: result.forPoints.map((p) => ({ text: p, audio: null, isLoadingAudio: false })),
        againstPoints: result.againstPoints.map((p) => ({ text: p, audio: null, isLoadingAudio: false })),
      };
      setDebatePoints(initialDebatePoints);
    } catch (error) {
      console.error("Error generating debate points:", error);
      toast({
        title: "Error",
        description: "Failed to generate debate points. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = (audioDataUri: string, pointText: string) => {
    if (audioRef.current) {
      if(activeAudio === pointText) { // If it's the current track, pause it
        audioRef.current.pause();
        setActiveAudio(null);
      } else { // If it's a new track, play it
        audioRef.current.src = audioDataUri;
        audioRef.current.play().catch((e) => {
          console.error("Audio playback failed:", e);
          toast({ variant: "destructive", title: "Playback Error", description: "Could not play audio." });
          setActiveAudio(null);
        });
        setActiveAudio(pointText);
      }
    }
  };

  const handleGenerateAudio = async (pointIndex: number, type: 'for' | 'against') => {
    if (isAudioLoadingRef.current && !debatePoints?.[type === 'for' ? 'forPoints' : 'againstPoints'][pointIndex]?.audio) {
        toast({
            title: "Please wait",
            description: "Another audio generation is already in progress.",
            variant: "default",
        });
        return;
    }

    const point = type === 'for' 
      ? debatePoints?.forPoints[pointIndex] 
      : debatePoints?.againstPoints[pointIndex];

    if (!point) return;
    
    if (point.audio) {
      playAudio(point.audio.media, point.text);
      return;
    }
    
    isAudioLoadingRef.current = true;

    setDebatePoints(prev => {
        if (!prev) return null;
        const newPoints = JSON.parse(JSON.stringify(prev));
        const targetPoint = type === 'for' ? newPoints.forPoints[pointIndex] : newPoints.againstPoints[pointIndex];
        targetPoint.isLoadingAudio = true;
        return newPoints;
    });

    try {
      const audioResult = await textToSpeech(point.text);
      setDebatePoints(prev => {
        if (!prev) return null;
        const newPoints = JSON.parse(JSON.stringify(prev));
        const targetPoint = type === 'for' ? newPoints.forPoints[pointIndex] : newPoints.againstPoints[pointIndex];
        targetPoint.audio = audioResult;
        targetPoint.isLoadingAudio = false;
        return newPoints;
      });
      playAudio(audioResult.media, point.text);
    } catch (error) {
      console.error("Error generating audio:", error);
      toast({
        title: "Audio Error",
        description: "Could not generate audio for this point.",
        variant: "destructive",
      });
       setDebatePoints(prev => {
        if (!prev) return null;
        const newPoints = JSON.parse(JSON.stringify(prev));
        const targetPoint = type === 'for' ? newPoints.forPoints[pointIndex] : newPoints.againstPoints[pointIndex];
        targetPoint.isLoadingAudio = false;
        return newPoints;
      });
    } finally {
        isAudioLoadingRef.current = false;
    }
  };


  const renderPoints = (points: DebatePoint[], type: 'for' | 'against') => {
      return (
        <Accordion type="single" collapsible className="w-full">
        {points.map((point, index) => (
          <AccordionItem value={`${type}-${index}`} key={`${type}-${index}`}>
            <div className="flex items-center justify-between py-4">
               <AccordionTrigger className="text-left flex-1 py-0 pr-4">{point.text}</AccordionTrigger>
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleGenerateAudio(index, type)}
                    disabled={point.isLoadingAudio || (isAudioLoadingRef.current && !point.audio)}
                    aria-label={`Play audio for: ${point.text}`}
                >
                    {point.isLoadingAudio ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      activeAudio === point.text ? <Pause className="w-5 h-5 text-primary" /> : <Play className="w-5 h-5" />
                    )}
                </Button>
            </div>
            <AccordionContent className="text-muted-foreground">
                <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-md">
                    <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                    <div>
                        <h4 className="font-semibold">AI Elaboration</h4>
                        <p>This is where a detailed explanation of the argument would appear. The AI can be prompted to elaborate on why this is a strong point, providing examples and evidence to support it.</p>
                    </div>
                </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
      )
  }

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <audio ref={audioRef} className="hidden" />
      <div className="text-center">
        <BookOpen className="w-20 h-20 text-accent mx-auto mb-4" />
        <h1 className="text-4xl font-extrabold tracking-tight font-headline text-primary sm:text-5xl md:text-6xl">
          Training Mode
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-muted-foreground sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Enter a topic to generate structured arguments. Explore both sides to build a comprehensive understanding.
        </p>
      </div>

      <Card className="mt-8 max-w-3xl mx-auto shadow-md">
        <CardHeader>
          <CardTitle className="font-headline">Enter Debate Topic</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleTopicSubmit} className="flex flex-col sm:flex-row gap-4">
            <div className="flex-grow">
              <Label htmlFor="topic-input" className="sr-only">Debate Topic</Label>
              <Input
                id="topic-input"
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., 'Is artificial intelligence a threat to humanity?'"
                disabled={isLoading}
              />
            </div>
            <Button type="submit" disabled={isLoading || !topic.trim()}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                "Generate Points"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {isLoading && !debatePoints && (
          <div className="text-center mt-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <p className="text-muted-foreground mt-2">Generating arguments...</p>
          </div>
      )}

      {debatePoints && (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-headline text-green-600">
                <ThumbsUp />
                For
              </CardTitle>
            </CardHeader>
            <CardContent>
                {renderPoints(debatePoints.forPoints, 'for')}
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-headline text-red-600">
                <ThumbsDown />
                Against
              </CardTitle>
            </CardHeader>
            <CardContent>
                {renderPoints(debatePoints.againstPoints, 'against')}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
