
"use client";

import { useState, useRef, useEffect } from "react";
import {
  actAsDebateOpponent,
  type ActAsDebateOpponentOutput,
} from "@/ai/flows/act-as-debate-opponent";
import {
  summarizeDebate,
  type SummarizeDebateOutput,
} from "@/ai/flows/summarize-debate";
import { textToSpeech } from "@/ai/flows/text-to-speech";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Loader2,
  Send,
  Zap,
  ShieldAlert,
  Mic,
  User,
  Bot,
  Sparkles,
  Trophy,
  Goal,
  BookCheck,
  TriangleAlert,
  Play,
  Pause,
  MicOff,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
}
declare const window: {
  SpeechRecognition: new () => SpeechRecognition;
  webkitSpeechRecognition: new () => SpeechRecognition;
};

type Message = {
  role: "user" | "assistant";
  content: string;
  audioDataUri?: string | null;
};

type Score = Omit<ActAsDebateOpponentOutput, "aiResponse" | "isDeviating" | "deviationReason">;
type Deviation = Pick<ActAsDebateOpponentOutput, "isDeviating" | "deviationReason">;


export default function CompetitorModeClient() {
  const [topic, setTopic] = useState("");
  const [hasStarted, setHasStarted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [score, setScore] = useState<Score | null>(null);
  const [summary, setSummary] = useState<SummarizeDebateOutput | null>(null);
  const [deviation, setDeviation] = useState<Deviation | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [activeAudio, setActiveAudio] = useState<string | null>(null);

  const { toast } = useToast();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (scrollAreaRef.current) {
      setTimeout(() => {
        scrollAreaRef.current?.scrollTo({
          top: scrollAreaRef.current.scrollHeight,
          behavior: "smooth",
        });
      }, 100);
    }
  }, [messages, isLoading]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        setInput(finalTranscript + interimTranscript);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        toast({ title: 'Speech Recognition Error', description: event.error, variant: 'destructive' });
        setIsRecording(false);
      };

      recognitionRef.current.onend = () => {
        if (isRecording) { // If it ends unexpectedly, stop recording state
            setIsRecording(false);
        }
      };
    }
  }, [toast]);

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      if (!recognitionRef.current) {
        toast({ title: 'Unsupported', description: 'Speech recognition is not supported in your browser.', variant: 'destructive' });
        return;
      }
      recognitionRef.current?.start();
      setIsRecording(true);
    }
  };

  const handleStartDebate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!topic.trim()) return;
    setHasStarted(true);
    setMessages([
      {
        role: "assistant",
        content: `Let's begin the debate on "${topic}". Please present your first argument.`,
      },
    ]);
  };

  const playAudio = (audioDataUri: string, content: string) => {
    if (audioRef.current) {
      if (activeAudio === content) {
        audioRef.current.pause();
        setActiveAudio(null);
      } else {
        audioRef.current.src = audioDataUri;
        audioRef.current.play().catch((e) => console.error("Audio playback failed:", e));
        setActiveAudio(content);
      }
    }
  };

  useEffect(() => {
    const audioElement = audioRef.current;
    const handleEnded = () => setActiveAudio(null);
    if (audioElement) {
        audioElement.addEventListener('ended', handleEnded);
        return () => {
            audioElement.removeEventListener('ended', handleEnded);
        };
    }
  }, []);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading || isSummarizing) return;
    if(isRecording) {
        recognitionRef.current?.stop();
        setIsRecording(false);
    }

    const userMessage: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    const conversationHistory = [...messages, userMessage]
      .map((m) => `${m.role}: ${m.content}`)
      .join("\n");

    try {
      const opponentResult = await actAsDebateOpponent({
          topic,
          userStatement: input,
          conversationHistory,
        });

      const { isDeviating, deviationReason, aiResponse, ...restOfScores } = opponentResult;

      setDeviation({ isDeviating, deviationReason });
      if (isDeviating) {
        toast({
          variant: "destructive",
          title: "Topic Deviation Warning",
          description: deviationReason,
        });
      }

      setScore(restOfScores);
      
      const assistantMessageWithoutAudio: Message = { role: "assistant", content: aiResponse, audioDataUri: null };
      setMessages((prev) => [...prev, assistantMessageWithoutAudio]);

      const audioResult = await textToSpeech(aiResponse);
      setMessages((prev) => 
        prev.map(m => m.content === aiResponse ? { ...m, audioDataUri: audioResult.media } : m)
      );
      playAudio(audioResult.media, aiResponse);

    } catch (error) {
      console.error("Error in debate:", error);
      toast({
        title: "An Error Occurred",
        description:
          "The AI opponent is having trouble responding. Please try again.",
        variant: "destructive",
      });
      setMessages((prev) => prev.filter((m) => m.content !== userMessage.content));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSummarize = async () => {
    if (isLoading || isSummarizing) return;
    setIsSummarizing(true);
    try {
      const conversationHistory = messages
        .map((m) => `${m.role}: ${m.content}`)
        .join("\n");
      const summaryResult = await summarizeDebate({
        topic,
        conversationHistory,
      });
      setSummary(summaryResult);
    } catch (error) {
      console.error("Error summarizing debate:", error);
      toast({
        title: "Error Summarizing",
        description: "Could not generate the debate summary. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSummarizing(false);
    }
  };

  const ScoreBar = ({ label, value }: { label: string; value: number }) => (
    <div className="space-y-1">
      <div className="flex justify-between items-baseline">
        <Label className="text-sm font-medium">{label}</Label>
        <span className="text-sm font-bold text-primary">{value}/10</span>
      </div>
      <Progress
        value={value * 10}
        className="h-2"
        aria-label={`${label}: ${value} out of 10`}
      />
    </div>
  );

  const resetDebate = () => {
    setTopic("");
    setHasStarted(false);
    setMessages([]);
    setInput("");
    setIsLoading(false);
    setIsSummarizing(false);
    setScore(null);
    setSummary(null);
    setDeviation(null);
  };

  if (!hasStarted) {
    return (
      <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Trophy className="w-24 h-24 text-accent mb-4" />
        <h1 className="text-4xl font-extrabold tracking-tight font-headline text-primary sm:text-5xl md:text-6xl">
          Competitor Mode
        </h1>
        <p className="mt-3 max-w-md text-center text-base text-muted-foreground sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Ready to test your mettle? Enter a topic and face our AI debate
          champion.
        </p>
        <Card className="mt-8 w-full max-w-xl mx-auto">
          <CardHeader>
            <CardTitle className="font-headline">
              Set the Debate Topic
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={handleStartDebate}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., 'Social media does more harm than good.'"
                className="flex-grow"
              />
              <Button type="submit" disabled={!topic.trim()}>
                Start Debate
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (summary) {
    return (
      <div className="container mx-auto py-12">
        <Card className="max-w-3xl mx-auto">
          <CardHeader className="text-center">
            <BookCheck className="mx-auto h-16 w-16 text-primary" />
            <CardTitle className="text-3xl font-headline mt-4">
              Debate Summary
            </CardTitle>
            <CardDescription>Topic: {topic}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-muted-foreground">Overall Performance Score</p>
              <p className="text-6xl font-bold text-primary">
                {summary.overallScore.toFixed(1)}
                <span className="text-3xl text-muted-foreground">/10</span>
              </p>
            </div>
            <div className="space-y-4 text-sm">
              <div>
                <h4 className="font-semibold flex items-center gap-2 text-green-600 dark:text-green-500">
                  <Zap /> Strongest Argument
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.strongestArgument}
                </p>
              </div>
              <div>
                <h4 className="font-semibold flex items-center gap-2 text-red-600 dark:text-red-500">
                  <ShieldAlert /> Weakest Argument
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.weakestArgument}
                </p>
              </div>
              <div>
                <h4 className="font-semibold flex items-center gap-2 text-blue-600 dark:text-blue-500">
                  <Sparkles /> Final Conclusion
                </h4>
                <p className="text-muted-foreground mt-1 bg-muted/50 p-3 rounded-md">
                  {summary.conclusion}
                </p>
              </div>
            </div>
             <Button onClick={resetDebate} className="w-full">
                Start a New Debate
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 h-[calc(100vh-5rem)]">
      <audio ref={audioRef} className="hidden" />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        <div className="lg:col-span-2 flex flex-col h-full bg-card border rounded-lg shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="font-headline text-lg">
              Debate: {topic}
            </CardTitle>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" disabled={isLoading || isSummarizing}>
                  <Goal className="mr-2 h-4 w-4" /> End Debate
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>End and Summarize Debate?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will end the current debate and generate a summary of your performance. You won't be able to send more messages.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSummarize}>
                    {isSummarizing ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    Summarize
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardHeader>
          <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
            <div className="space-y-6">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex items-start gap-3 w-full",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  {message.role === "assistant" && (
                    <Avatar>
                      <AvatarFallback>
                        <Bot />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={cn(
                      "max-w-xl rounded-lg p-3 text-sm shadow",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    )}
                  >
                     <p className="whitespace-pre-wrap">{message.content}</p>
                    {message.role === 'assistant' && (
                        <div className="mt-2">
                            {message.audioDataUri === null ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                            ) : message.audioDataUri ? (
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => playAudio(message.audioDataUri!, message.content)}>
                                    {activeAudio === message.content ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                                </Button>
                            ) : null}
                        </div>
                    )}
                  </div>
                  {message.role === "user" && (
                    <Avatar>
                      <AvatarFallback>
                        <User />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="flex items-start gap-3 justify-start">
                  <Avatar>
                    <AvatarFallback>
                      <Bot />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-muted rounded-lg p-3 shadow">
                    <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          <div className="p-4 border-t bg-background/80 rounded-b-lg">
            <div className="relative">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isRecording ? "Listening..." : "Type your argument..."}
                className="pr-24 min-h-[40px]"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                disabled={isLoading || isSummarizing}
                rows={1}
              />
              <div className="absolute top-1/2 -translate-y-1/2 right-3 flex gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleRecording}
                  disabled={isLoading || isSummarizing}
                  aria-label="Use Voice Input"
                  className={cn(isRecording && "text-destructive")}
                >
                  {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
                <Button
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={isLoading || !input.trim() || isSummarizing}
                  aria-label="Send Message"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 h-full overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2 text-base">
                <TriangleAlert className="text-accent" /> Topic Deviation
              </CardTitle>
              <CardDescription>
                Monitors if you stray from the topic.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {deviation?.isDeviating ? (
                  <div className="text-sm bg-destructive/10 p-3 rounded-md border border-destructive/20">
                    <p className="font-bold text-red-600 dark:text-red-500">Off-Topic Warning:</p>
                    <p className="text-muted-foreground mt-1">{deviation.deviationReason}</p>
                  </div>
                ) : deviation ? (
                  <div className="text-center text-muted-foreground py-4 text-sm">
                    <p className="font-medium text-green-600">On topic. Keep it up!</p>
                  </div>
                ) : (
                <div className="text-center text-muted-foreground py-4 text-sm">
                  Send a message to check for topic deviation.
                </div>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2 text-base">
                <Trophy className="text-accent" /> Real-time Scoring
              </CardTitle>
              <CardDescription>
                Your last argument's performance.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {score ? (
                <>
                  <ScoreBar
                    label="Argument Strength"
                    value={score.argumentStrength}
                  />
                  <ScoreBar
                    label="Logical Consistency"
                    value={score.logicalConsistency}
                  />
                  <ScoreBar label="Relevance" value={score.relevance} />
                  <ScoreBar label="Clarity" value={score.clarity} />
                </>
              ) : (
                <div className="text-center text-muted-foreground py-8 text-sm">
                  Submit an argument to see your score.
                </div>
              )}
            </CardContent>
          </Card>
          <Card className="flex-grow">
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2 text-base">
                <Sparkles className="text-accent" /> AI Analysis
              </CardTitle>
              <CardDescription>Feedback on your last statement.</CardDescription>
            </CardHeader>
            <CardContent>
              {score ? (
                <div className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-semibold flex items-center gap-2 text-green-600 dark:text-green-500">
                      <Zap /> Strong Points
                    </h4>
                    <p className="text-muted-foreground mt-1">
                      {score.strongPointExplanation}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold flex items-center gap-2 text-red-600 dark:text-red-500">
                      <ShieldAlert /> Weak Points
                    </h4>
                    <p className="text-muted-foreground mt-1">
                      {score.weakPointExplanation}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold flex items-center gap-2 text-blue-600 dark:text-blue-500">
                      <Sparkles /> Suggestions
                    </h4>
                    <p className="text-muted-foreground mt-1">
                      {score.improvementSuggestions}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8 text-sm">
                  Submit an argument to get AI analysis.
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
